from django.db import models

# Create your models here.


class Admin(models.Model):
    emailid = models.CharField(max_length=50,primary_key=True)
    password = models.CharField(max_length=20)

    Objects = models.Manager()
    class Meta:
        db_table="admin"



class Course(models.Model):
    course_id = models.AutoField(primary_key=True)
    course_name= models.CharField(max_length=20)

    Objects = models.Manager()
    class Meta:
        db_table="course"


class Trainer(models.Model):
    trainer_id = models.AutoField(blank=True,null=False,primary_key=True)
    trainer_name= models.CharField(max_length=20)
    email_id = models.CharField(unique=True,max_length=50,)
    password = models.CharField(max_length=20)
    phone = models.CharField(max_length=20)
    city = models.CharField(max_length=20)
    adress = models.CharField(max_length=20, null=True)
    pincode = models.IntegerField(blank=True, null=True)
    state = models.CharField(max_length=20)

    Objects = models.Manager()
    class Meta:
        db_table="trainer"


class Student(models.Model):
    student_id = models.AutoField(blank=True,null=False,primary_key=True)
    student_name= models.CharField(max_length=20)
    email_id = models.CharField(unique=True,max_length=50,)
    password = models.CharField(max_length=20)
    phone = models.CharField(max_length=20)
    city = models.CharField(max_length=20)
    adress = models.CharField(max_length=20, null=True)
    pincode = models.IntegerField(blank=True, null=True)
    state = models.CharField(max_length=20)

    Objects = models.Manager()
    class Meta:
        db_table="student"

class Collage(models.Model):
    collage_code = models.AutoField(blank=True,null=False,primary_key=True)
    name = models.CharField(max_length=20)
    adress = models.CharField(max_length=20)
    city = models.CharField(max_length=20)
    pincode = models.CharField(max_length=20)
    state = models.CharField(max_length=20)

    Objects = models.Manager()
    class Meta:
        db_table="collage"



class Batch(models.Model):
    batch_code = models.AutoField(blank=True,null=False,primary_key=True)
    collage_code = models.ForeignKey('Collage',models.DO_NOTHING,db_column='collage_code',blank=True,null=True)
    course_id = models.ForeignKey('Course',models.DO_NOTHING,db_column='course_id',blank=True,null=True)
    start_date = models.DateField(max_length=20,blank=True, null=True)
    end_date = models.DateField(max_length=20,blank=True, null=True)
    trainer_id = models.ForeignKey('Trainer',models.DO_NOTHING,db_column='trainer_id',blank=True,null=True)
    hours_per_day = models.CharField(max_length=20,blank=True, null=True)
    total_days = models.CharField(max_length=20,blank=True, null=True)
    hours_days = models.CharField(max_length=20,blank=True, null=True)
    batch_status = models.CharField(max_length=20,blank=True, null=True)
    collage_coordinator= models.CharField(max_length=20,blank=True, null=True)


    Objects = models.Manager()
    class Meta:
        db_table="batch"



class Checklist(models.Model):
    id = models.AutoField(blank=True,null=False,primary_key=True)
    batch_code = models.ForeignKey('Batch',models.DO_NOTHING,db_column='batch_code',blank=True,null=True)
    traine_alloted = models.CharField(max_length=20,blank=True, null=True)
    student_registered_done = models.CharField(max_length=20,blank=True, null=True)
    softwere_installed = models.CharField(max_length=20,blank=True, null=True)
    topic_scheduled = models.CharField(max_length=20,blank=True, null=True)
    schedule_generated = models.CharField(max_length=20,blank=True, null=True)

    Objects = models.Manager()
    class Meta:
        db_table="checklist"




class Topics(models.Model):
    topics_id =  models.AutoField(blank=True,null=False,primary_key=True)
    course_id = models.ForeignKey('Course',models.DO_NOTHING,db_column='course_id',blank=True,null=True)
    topic =  models.CharField(max_length=20,blank=True, null=True)
    Objects = models.Manager()
    class Meta:
        db_table="topics"




class Studentbatch(models.Model):
    student_name = models.ForeignKey('Student', models.DO_NOTHING, db_column='student_name', blank=True, null=True)
    batch_code = models.ForeignKey('Batch', models.DO_NOTHING, db_column='batch_code', blank=True, null=True)
    trainer_id = models.ForeignKey('Trainer', models.DO_NOTHING, db_column='trainer', blank=True, null=True)
    date = models.CharField(max_length=20,blank=True, null=True)
    attendence = models.CharField(max_length=20,blank=True, null=True)
    Objects = models.Manager()
    class Meta:
        db_table="studentbatch"

