from django.http import HttpResponse
from django.shortcuts import render
from .models import Admin
from .models import Trainer
from .models import Course
from .models import Topics
from .models import Batch
from .models import Collage
from .models import Student
from .models import Checklist
from .models import Studentbatch
from qrcode import *



def index(request):
    return render(request, 'tracking_app/index.html')


def adminchangepassword(request):
    return render(request, 'tracking_app/adminchangepassword.html')


def adminchange(request):
    # get input the changepasswordform
    currentpassword = request.POST.get("textpassword")
    newpassword = request.POST.get("textnewpassword")
    conformpassworspassword = request.POST.get("textconformpassword")

    if currentpassword == request.session['password']:
        if newpassword == conformpassworspassword:
            # get the row from the data bade
            adminobj = Admin.Objects.get(emailid=request.session['email'], password=request.session['password'])
            adminobj.password = newpassword
            adminobj.save()
            return HttpResponse("password updated")
        else:
            return HttpResponse("new password do not match")
    else:
        return HttpResponse("current paswword is invalid")


def adminform(request):
    return render(request, 'tracking_app/adminform.html')


def admin(request):
    # get input to search
    email = request.POST.get("textemail")
    password = request.POST.get("textpassword")
    # store data in session


    try:
        adminobj = Admin.Objects.get(emailid=email, password=password)
        return render(request, 'tracking_app/adminhome.html')
    except:
        return HttpResponse("no such information is stored")


def trainer(request):
    vname = request.POST.get("traineename")
    vemailid = request.POST.get("textemail")
    vpassword = request.POST.get("textpassword")
    vphone = request.POST.get("phonenumber")
    vcity = request.POST.get("textcity")
    vaddress = request.POST.get("textadress")
    vpincode = request.POST.get("pinumber")
    vstate = request.POST.get("textstate")

    try:
        traineesobj = Trainer(trainer_name=vname, email_id=vemailid, password=vpassword, phone=vphone,
                          city=vcity,
                          adress=vaddress, pincode=vpincode, state=vstate)
        traineesobj.save()
    except:
        return HttpResponse("users is registerd")

def student(request):
     vname = request.POST.get("traineename")
     vemailid = request.POST.get("textemail")
     vpassword = request.POST.get("textpassword")
     vphone = request.POST.get("phonenumber")
     vcity = request.POST.get("textcity")
     vaddress = request.POST.get("textadress")
     vpincode = request.POST.get("pinumber")
     vstate = request.POST.get("textstate")
     try:
         studentobj = Student(student_name=vname, email_id=vemailid, password=vpassword, phone=vphone,
                          city=vcity,
                          adress=vaddress, pincode=vpincode, state=vstate)
         studentobj.save()
     except:
        return HttpResponse("student is registerd")


def courseform(request):
    return render(request, 'tracking_app/courseform.html')


def studentform(request):
    return render(request, 'tracking_app/studentform.html')

def trainerform(request):
    return render(request, 'tracking_app/trainerform.html')



def trainerqrcode(request):
    return render(request, 'tracking_app/trainerqrcode.html')

def trainerqr(request):
    if request.method == 'POST':
        vname = request.POST["traineename"]
        vemailid = request.POST ["textemail"]
        vpassword = request.POST["textpassword"]
        vphone = request.POST ["phonenumber"]
        vcity = request.POST ["textcity"]
        vaddress = request.POST ["textadress"]
        vpincode = request.POST ["pinumber"]
        vstate = request.POST ["textstate"]
        traineesobj=['vname','vemailid','vpassword','vphone','vcity','vaddress','vpincode','vstate']
        img = make(traineesobj)
        img.save('tracking_app/static/image/test.png')
    else:
        pass
    return render(request, 'tracking_app/trainerqrcode.html', {'traineesobj': traineesobj})

def collageform(request):
    return render(request, 'tracking_app/collageform.html')


def viewcollage(request):
    collageobj=Collage.Objects.all()
    return render(request,'tracking_app/viewcollage.html',{"collageobj":collageobj})

def collage(request):

    vname = request.POST.get("textname")
    vadress = request.POST.get("textadress")
    vcity = request.POST.get("textcity")
    vpincode= request.POST.get("pinnumber")
    vstate  = request.POST.get("textstate")

    collageobj = Collage( name=vname, adress=vadress,city=vcity,pincode=vpincode,
                         state=vstate)
    collageobj.save()
    return HttpResponse("users is registerd")




def batchform(request):
    courseobj = Course.Objects.all()
    collageobj=Collage.Objects.all()
    trainerobj = Trainer.Objects.all()
    return render(request, 'tracking_app/batchform.html',
                  {"courseobj": courseobj,
                  "collageobj": collageobj
                  ,"trainerobj":trainerobj})


def batch(request):
    vbatch_code = request.POST.get("batchcode")
    vcollage_code = request.POST.get("collagecode")
    vcourse_id = request.POST.get("courseid")
    vstart_date = request.POST.get("startdate")
    vend_date = request.POST.get("enddate")
    vtrainer_id = request.POST.get("traineeid")
    vhours_per_day = request.POST.get("texthoursday")
    vtotal_days= request.POST.get("texttotal")
    vhours_days = request.POST.get("texthours")
    vbatch_status = request.POST.get("textbatch")
    vcollage_coordinator = request.POST.get("tetxcollage")
    collageobj=Collage.Objects.get(collage_code=vcollage_code)
    courseobj=Course.Objects.get(course_id=vcourse_id)
    trainerobj=Trainer.Objects.get(trainer_id=vtrainer_id)

    batchobj = Batch(collage_code=collageobj,course_id=courseobj, start_date=vstart_date, end_date=vend_date,
                          hours_per_day=vhours_per_day, trainer_id= trainerobj,
                          total_days=vtotal_days,hours_days=vhours_days,batch_status=vbatch_status, collage_coordinator=vcollage_coordinator)
    batchobj.save()
    return HttpResponse("batch is created")





def checklist(request):
    batchobj=Batch.Objects.all()
    return render(request, 'tracking_app/checklist.html', {"batchobj": batchobj})

def check(request):
    # vid = request.POST.get("id")
    vbatchcode = request.POST.get("batchcode")
    vtraine_alloted = request.POST.get("texttrainer")
    vstudent_registration_done = request.POST.get("textstudent")
    vsoftwere_installed = request.POST.get("textsoftwere")
    vtopic_scheduled = request.POST.get("texttopic")
    vschedule_generated = request.POST.get("textgenrator")
    batchobj = Batch.Objects.get(batch_code=vbatchcode)

    checkobj=Checklist(batch_code=batchobj,traine_alloted=vtraine_alloted,
                       student_registered_done=vstudent_registration_done,softwere_installed=vsoftwere_installed,
                       topic_scheduled=vtopic_scheduled,schedule_generated=vschedule_generated)
    checkobj.save()
    return HttpResponse("checklist saved")

def studentsigninform(request):
    return render(request, 'tracking_app/studentsigninform.html')

def listoflogin(request):
    return render(request, 'tracking_app/listoflogin.html')


def viewtrainer(request):
    trainerobj = Trainer.Objects.all()
    return render(request, 'tracking_app/viewtrainer.html',{"trainerobj": trainerobj})

def studentview(request):
    studentobj = Student.Objects.all()
    return render(request, 'tracking_app/studentview.html',{"studentobj": studentobj})



def viewbatch(request):
    batchobj = Batch.Objects.all()
    return render(request, 'tracking_app/viewbatch.html', {"batchobj": batchobj})



def editstudent(request,x):
    vid=x
    studentobj=Student.Objects.get(student_id=vid)
    return render(request,'tracking_app/editstudent.html', {"studentobj": studentobj})


def editstud(request):
    vid = request.POST.get("traineeid")
    vname = request.POST.get("traineename")
    vemailid = request.POST.get("textemail")
    vphone = request.POST.get("phonenumber")
    vcity = request.POST.get("textcity")
    vaddress = request.POST.get("textadress")
    vpincode = request.POST.get("pinumber")
    vstate = request.POST.get("textstate")
    studentobj=Student.Objects.get(student_id=vid)
    studentobj.student_name=vname
    studentobj.email_id=vemailid
    studentobj.phone=vphone
    studentobj.city=vcity
    studentobj.adress=vaddress
    studentobj.pincode = vpincode
    studentobj.state=vstate
    studentobj.save()
    return HttpResponse("updated")



def editemp(request,x):
    vid=x
    trainerobj=Trainer.Objects.get(trainer_id=vid)
    return render(request,'tracking_app/editemp.html', {"trainerobj": trainerobj})

def edit(request):
    vid = request.POST.get("traineeid")
    vname = request.POST.get("traineename")
    vemailid = request.POST.get("textemail")
    vphone = request.POST.get("phonenumber")
    vcity = request.POST.get("textcity")
    vaddress = request.POST.get("textadress")
    vpincode = request.POST.get("pinumber")
    vstate = request.POST.get("textstate")
    trainerobj=Trainer.Objects.get(trainer_id=vid)
    trainerobj.trainer_name=vname
    trainerobj.email_id=vemailid
    trainerobj.phone=vphone
    trainerobj.city=vcity
    trainerobj.adress=vaddress
    trainerobj.pincode = vpincode
    trainerobj.state=vstate
    trainerobj.save()
    return HttpResponse("updated")

def course(request):
    vcourse_id=request.POST.get("textcourse")
    vname = request.POST.get("coursename")
    courseobj = Course(course_id=vcourse_id,course_name=vname)
    courseobj.save()
    return HttpResponse("course is registerd")



def viewcourse(request):
    courseobj = Course.Objects.all()
    return render(request, 'tracking_app/viewcourse.html', {"courseobj":courseobj})

def viewchecklist(request):
    checkobj = Checklist.Objects.all()
    return render(request, 'tracking_app/viewchecklist.html', {"checkobj":checkobj})




def selectcourse(request):
    selectobj = Course.Objects.all()
    return render(request, 'tracking_app/selectcourse.html', {"selectobj":selectobj})

def viewsession(request):
    topicobj = Topics.Objects.all()
    return render(request, 'tracking_app/viewsession.html', {"topicobj":topicobj})


def topicform(request,x,y):
    return render(request,'tracking_app/topicform.html', {'course_id': x, 'course_name': y})


def topicupdated(request):
    vcourse_id=request.POST.get("textcourse")
    vtopic=request.POST.get("texttopic")
    courseobj=Course.Objects.get(course_id =vcourse_id)
    try:
        topicobj=Topics(course_id =courseobj,topic=vtopic)
        topicobj.save()
        return HttpResponse("Topic Update")
    except:
        return HttpResponse("Topic NOT Update")



def trainersigninform(request):
    return render(request,"tracking_app/trainersigninform.html")

def studentsigninform(request):
    return render(request,"tracking_app/studentsigninform.html")

def studentsignin(request):
    vemail = request.POST.get("textemail")
    vpassword = request.POST.get("textpassword")

    studentobj = Student.Objects.get(email_id=vemail, password=vpassword)
    request.session["vemailid"] = studentobj.email_id
    request.session["vpassword"] = studentobj.password
    return render(request,"tracking_app/studentheader.html")


def trainersignin(request):
    vemail = request.POST.get("textemail")
    vpassword = request.POST.get("textpwd")

    # get the row from the data bade
    trainerobj = Trainer.Objects.get(email_id=vemail, password=vpassword)
    request.session["vemailid"]=trainerobj.email_id
    request.session["vpassword"] = trainerobj.password

    return render(request,"tracking_app/traineerheader.html")





def trainerchangepassword(request):
    return render(request,"tracking_app/trainerchangepassword.html")


def trainernchange(request):
    # get input the changepasswordform
    currentpassword = request.POST.get("textpassword")
    newpassword = request.POST.get("textnewpassword")
    conformpassworspassword = request.POST.get("textconformpassword")

    if currentpassword == request.session['password']:
        if newpassword == conformpassworspassword:
            # get the row from the data bade
            trainerobj = Trainer.Objects.get(email_id=request.session['email'], password=request.session['password'])
            trainerobj.password = newpassword
            trainerobj.save()
            return HttpResponse("password updated")
        else:
            return HttpResponse("new password do not match")
    else:
        return HttpResponse("current paswword is invalid")


def assignstudentstobatch(request):
    return render(request,"tracking_app/assignstudentstobatch.html")





def studentattendence(request,x,y):
    studentobj = Student.Objects.all()
    return render(request,'tracking_app/studentattendence.html', {"batch_code":x,"trainer_id":y,"studentobj": studentobj})


def updateattendence(request):
    vbatchcode = request.POST.get("batchcode")
    vstudentname = request.POST.get("studentname")
    vtrainer_id = request.POST.get("trainer_id")
    vattendence = request.POST.get("attendence")
    vdate = request.POST.get("date")
    trainerobj=Trainer.Objects.get(trainer_id=vtrainer_id)
    batchobj=Batch.Objects.get(batch_code=vbatchcode)
    studentobj=Student.Objects.get(student_name=vstudentname)
    try:
        studentbatchobj=Studentbatch(trainer_id=trainerobj,batch_code=batchobj,student_name=studentobj,attendence=vattendence,date=vdate)
        studentbatchobj.save()
        return HttpResponse("student registerd")
    except:
         return HttpResponse(" not student registerd")

