from django.conf.urls import url,include
from.import views



urlpatterns = [
    url(r'^index/$', views.index, name="index method to load html"),
    url(r'^adminform/$', views.adminform, name="index method to load html"),
    url(r'^courseform/$', views.courseform, name="index method to load html"),
    url(r'^trainerform/$', views.trainerform, name="index method to load html"),
    url(r'^collageform/$', views.collageform, name="index method to load html"),
    url(r'^collage/$', views.collage, name="index method to load html"),
    url(r'^batchform/$', views.batchform, name="index method to load html"),
    url(r'^batch/$', views.batch, name="index method to load html"),

    url(r'^checklist/$', views.checklist, name="index method to load html"),
    url(r'^topicform/(\d+)/([\w\s]+)/$', views.topicform, name="index method to load html"),
    url(r'^admin/$', views.admin, name="index method to load html"),
    url(r'^adminchangepassword/$', views.adminchangepassword, name="index method to load html"),
    url(r'^adminchange/$', views.adminchange, name="index method to load html"),
    url(r'^studentsigninform/$', views.studentsigninform, name="index method to load html"),
    url(r'^studentsignin/$', views.studentsignin, name="index method to load html"),
    url(r'^trainer/$', views.trainer, name="index method to load html"),
    url(r'^viewtrainer/$', views.viewtrainer, name="index method to load html"),
    url(r'^studentview/$', views.studentview, name="index method to load html"),
    url(r'^viewcourse/$', views.viewcourse, name="index method to load html"),
    url(r'^viewcollage/$', views.viewcollage, name="index method to load html"),
    url(r'^editemp/(\d+)/$', views.editemp, name="index method to load html"),
    url(r'^edit/$', views.edit, name="index method to load html"),
    url(r'^editstudent/(\d+)/$', views.editstudent, name="index method to load html"),
    url(r'^editstud/$', views.editstud, name="index method to load html"),
    url(r'^listoflogin/$', views.listoflogin, name="index method to load html"),

    url(r'^course/$', views.course, name="index method to load html"),
    url(r'^selectcourse/$', views.selectcourse, name="index method to load html"),
    url(r'^topicupdated/$', views.topicupdated, name="index method to load html"),
    url(r'^viewsession/$', views.viewsession, name="index method to load html"),
    url(r'^viewbatch/$', views.viewbatch, name="index method to load html"),
    url(r'^check/$', views.check, name="index method to load html"),
    url(r'^viewchecklist/$', views.viewchecklist, name="index method to load html"),
    url(r'^trainersigninform/$', views.trainersigninform, name="index method to load html"),
    url(r'^trainersignin/$', views.trainersignin, name="index method to load html"),
    url(r'^trainerchangepassword/$', views.trainerchangepassword, name="index method to load html"),
    url(r'^trainernchange/$', views.trainernchange, name="index method to load html"),
    url(r'^trainerqrcode/$', views.trainerqrcode, name="index method to load html"),
    url(r'^trainerqr/$', views.trainerqr, name="index method to load html"),

    url(r'^studentform/$', views.studentform, name="index method to load html"),
    url(r'^student/$', views.student, name="index method to load html"),
    url(r'^assignstudentstobatch/$', views.assignstudentstobatch, name="index method to load html"),
    url(r'^studentattendence/(\d+)/([\w\s]+)/$',views.studentattendence, name="index method to load html"),
    url(r'^updateattendence/$',views.updateattendence, name="index method to load html"),
]